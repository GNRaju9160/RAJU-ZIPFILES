//
//  ViewController2.swift
//  UserDefault
//
//  Created by Training on 30/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    @IBOutlet weak var txtFldUnSin: UITextField!
    @IBOutlet weak var txtFldPassSin: UITextField!
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtFldUnSin.text = ""
        txtFldPassSin.text = ""
        
    }
    
    @IBAction func btnlogin(_ sender: Any) {
    }
    
 }


    


