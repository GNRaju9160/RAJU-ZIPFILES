//
//  ViewControllerImage.swift
//  UiViewAnimation
//
//  Created by Training on 25/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewControllerImage: UIViewController {
    
    @IBOutlet weak var imgVw: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func btnPlay(_ sender: Any) {
        UIView.animate(withDuration: 1, animations:{
            self.imgVw.frame.origin.y -= 200
            
        }){_ in
            UIView.animateKeyframes(withDuration: 1, delay: 0.25, options: [.autoreverse,.repeat], animations: {
                self.imgVw.frame.origin.y += 200
            })
          
        }
     
    }
}
