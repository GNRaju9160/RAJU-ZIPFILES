//
//  OptionsViewController.swift
//  UiViewAnimation
//
//  Created by Training on 25/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class OptionsViewController: UIViewController {
    @IBOutlet weak var viewOption: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.viewOption.alpha = 0.0
        
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnOption(_ sender: Any) {
        if self.viewOption.alpha == 0.0 {
            
            UIView.animate(withDuration: 1.5, delay: 0.2, options: .curveEaseOut, animations: {
                self.viewOption.alpha = 1.0
                
                self.viewOption.layer.cornerRadius = 5.0
            })
            
        }else {
            UIView.animate(withDuration: 1.5, delay: 0.2, options: .curveEaseOut, animations: {
                self.viewOption.alpha = 0.0
            })
        }
    }
}
