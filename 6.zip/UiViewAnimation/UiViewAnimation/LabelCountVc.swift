//
//  LabelCountVc.swift
//  UiViewAnimation
//
//  Created by Training on 25/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class LabelCountVc: UIViewController {
    @IBOutlet weak var lblCount: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
   
    }


}
