//
//  RotateImgViewController.swift
//  UiViewAnimation
//
//  Created by Training on 25/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class RotateImgViewController: UIViewController {
    @IBOutlet weak var imgVw: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func btnRotate(_ sender: Any) {
        
        
        imgVw.transform = imgVw.transform.rotated(by: .pi/2)
        getRotateAngles()
    }
    func getRotateAngles() {
        let radians = atan2(imgVw.transform.b, imgVw.transform.a)
        var degrees = radians * 180 / .pi
        degrees.round()
        let realDegrees = degrees >= 0 ? abs(degrees) : 360 + degrees

    }
    @IBAction func btnReset(_ sender: Any) {
        
      
        
                UIView.animate(withDuration: 1.0, animations: ({
                    self.imgVw.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
            }))
           }

    

    @IBAction func btn360(_ sender: Any) {
        imgVw.transform = CGAffineTransform(scaleX: 2, y: 2)
        imgVw.transform = CGAffineTransform(translationX: -256, y: -256)
        imgVw.transform = CGAffineTransform(rotationAngle: CGFloat.pi)
        imgVw.transform = CGAffineTransform.identity
        
      rotateAnyView(view: imgVw, fromValue: 0, toValue: Float(2.0 * M_PI), duration: 1)
        
        
        
    }
    
    func rotateAnyView(view: UIView, fromValue: Double, toValue: Float, duration: Double = 1) {
        let animation = CABasicAnimation(keyPath: "transform.rotation")
        animation.duration = duration
        animation.fromValue = fromValue
        animation.toValue = toValue
        view.layer.add(animation, forKey: nil)
    }
    }



