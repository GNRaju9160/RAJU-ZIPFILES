//
//  ViewController.swift
//  UiViewAnimation
//
//  Created by Training on 25/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var lblWelcome: UILabel!
    
    @IBOutlet weak var lblRaj: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
   self.lblWelcome.alpha = 0
        self.lblRaj.alpha = 0
        
        
        
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIView.animate(withDuration: 1, animations: {
            self.lblWelcome.alpha = 1
        }, completion: {(true) in
            
            UIView.animate(withDuration: 1, animations: {
                self.lblRaj.alpha = 0.8
            }, completion: {(true) in
            
            
        })
        
        
    })
    
    
    }

}

