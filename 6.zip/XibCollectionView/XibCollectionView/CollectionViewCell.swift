//
//  CollectionViewCell.swift
//  XibCollectionView
//
//  Created by Training on 14/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var clcImg: UIImageView!
    @IBOutlet weak var lblCell: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
