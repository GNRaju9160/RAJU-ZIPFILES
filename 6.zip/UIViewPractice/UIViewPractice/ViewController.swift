//
//  ViewController.swift
//  UIViewPractice
//
//  Created by Training on 11/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var lblText: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func ActionStates(_ sender: Any) {
 
        
        
    }
    
    
    @IBAction func actionWonders(_ sender: Any) {
    }
    

}

