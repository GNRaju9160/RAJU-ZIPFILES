//
//  UIVw2.swift
//  UIViewPractice
//
//  Created by Training on 11/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class UIVw2: UIViewController,UICollectionViewDataSource,UICollectionViewDragDelegate {
   
   
    let arrStates = ["i1","i2","i3","i4","i5","i6","i7","i8","i9","i10"]
    let arrFoodImages: [UIImage] = [
        UIImage(named: "i1")!,
        UIImage(named: "i2")!,
        UIImage(named: "i3")!,
        UIImage(named: "i4")!,
        UIImage(named: "i5")!,
        UIImage(named: "i6")!,
        UIImage(named: "i7")!,
        UIImage(named: "i8")!,
        UIImage(named: "i9")!,
        UIImage(named: "i10")!,
       
    ]
    let arrWorld = ["w1","w2","w3","w4","w5","w6","w7"]
    let arrWorld: [UIImage] = [
        UIImage(named: "w1")!,
        UIImage(named: "w2")!,
        UIImage(named: "w3")!,
        UIImage(named: "w4")!,
        UIImage(named: "w5")!,
        UIImage(named: "w6")!,
        UIImage(named: "w7")!,
       
        
        ]
    

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    @IBAction func actionBack(_ sender: Any) {
    }
    

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        <#code#>
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        <#code#>
    }
    
    func collectionView(_ collectionView: UICollectionView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        <#code#>
    }
    
}
