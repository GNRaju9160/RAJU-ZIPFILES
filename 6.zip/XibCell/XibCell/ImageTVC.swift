//
//  ImageTVC.swift
//  XibCell
//
//  Created by Training on 14/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ImageTVC: UITableViewCell {
    @IBOutlet weak var imgVw: UIImageView!
   
    @IBOutlet weak var lblNames: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
