//
//  ViewController.swift
//  CollectionViewAddImagesGallary
//
//  Created by Training on 18/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UIImagePickerControllerDelegate,,UINavigationControllerDelegate  {
    
    
    @IBOutlet weak var clcVwGallary: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func btnAddImages(_ sender: Any) {
        var mypickerController = UIImagePickerController()
        mypickerController.delegate = self
        mypickerController.sourceType = UIImagePickerController.SourceType.photoLibrary
        
        self.present(mypickerController, animated: true, completion: nil)
        
        
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        imgVwAdd.image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        self.dismiss(animated: true, completion: nil)

        
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
 
    }

}

