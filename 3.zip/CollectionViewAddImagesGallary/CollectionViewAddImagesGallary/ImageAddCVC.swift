//
//  ImageAddCVC.swift
//  CollectionViewAddImagesGallary
//
//  Created by Training on 18/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ImageAddCVC: UICollectionViewCell {
    @IBOutlet weak var imgVwAdd: UIImageView!
    
}
