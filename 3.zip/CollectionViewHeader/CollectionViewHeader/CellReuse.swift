//
//  CellReuse.swift
//  CollectionViewHeader
//
//  Created by Training on 11/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class CellReuse: UICollectionReusableView {
    @IBOutlet weak var lblText: UILabel!
    
}
