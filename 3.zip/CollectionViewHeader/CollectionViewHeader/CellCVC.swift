//
//  CellCVC.swift
//  CollectionViewHeader
//
//  Created by Training on 11/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class CellCVC: UICollectionViewCell {
    
    @IBOutlet weak var imgVw: UIImageView!
}
