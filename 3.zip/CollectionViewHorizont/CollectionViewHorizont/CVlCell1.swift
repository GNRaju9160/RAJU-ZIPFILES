//
//  CVlCell1.swift
//  CollectionViewHorizont
//
//  Created by Training on 06/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class CVlCell1: UICollectionViewCell {
    @IBOutlet weak var imgVw1: UIImageView!
    
}
