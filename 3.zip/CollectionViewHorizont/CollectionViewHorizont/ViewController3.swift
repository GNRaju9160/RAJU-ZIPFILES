//
//  ViewController3.swift
//  CollectionViewHorizont
//
//  Created by Training on 06/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController3: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
   
    
    @IBOutlet weak var clvFrame: UICollectionView!
    var arrImagesProfile = ["1","2","3","4","5","6","7","8","9"]
    var arrImagesMobiles = ["10","11","12","13","14","15","16","17"]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       return arrImagesProfile.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
     
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CVlCell1", for: indexPath) as! CVlCell1
        cell.imgVw1.image = UIImage(named: arrImagesProfile[indexPath.item])
   
     
        
        
        
        return cell
    }
    }


