//
//  imageCvc.swift
//  CollectionViewHorizont
//
//  Created by Training on 06/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class imageCvc: UICollectionViewCell {
    @IBOutlet weak var imgVwProfile: UIImageView!
    
}
