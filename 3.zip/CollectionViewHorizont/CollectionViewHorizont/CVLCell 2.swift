//
//  CVLCell 2.swift
//  CollectionViewHorizont
//
//  Created by Training on 06/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class CVLCell_2: UICollectionViewCell {
    @IBOutlet weak var imgVw2: UIImageView!
    
}
