//
//  ViewController2.swift
//  CollectionViewHorizont
//
//  Created by Training on 06/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController2: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    
    @IBOutlet weak var ProfileImagesCVC: UICollectionView!
    
    var arrImagesProfile = ["1","2","3","4","5","6","7","8","9"]
    var arrImagesMobiles = ["10","11","12","13","14","15","16","17"]
    override func viewDidLoad() {
        super.viewDidLoad()

    
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
     return arrImagesProfile.count
    
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
  let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProfileImagesCVC", for: indexPath) as! ProfileImagesCVC
        cell.imgVwProfile.image = UIImage(named: arrImagesProfile[indexPath.item])
        cell.imgVwMobiles.image = UIImage(named: arrImagesMobiles[indexPath.item])
        return cell
    }

    

}
