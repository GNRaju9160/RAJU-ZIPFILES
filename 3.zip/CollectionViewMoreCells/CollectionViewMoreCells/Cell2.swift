//
//  Cell2.swift
//  CollectionViewMoreCells
//
//  Created by Training on 25/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class Cell2: UICollectionViewCell {
    @IBOutlet weak var imgVw2: UIImageView!
    
}
