//
//  Cell1.swift
//  CollectionViewMoreCells
//
//  Created by Training on 25/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class Cell1: UICollectionViewCell {
    @IBOutlet weak var imgVw1: UIImageView!
    
}
