
import UIKit
import PinterestLayout

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
   
   
    
    
    var arrImages = [(#imageLiteral(resourceName: "a1")),(#imageLiteral(resourceName: "a5")),(#imageLiteral(resourceName: "a4")),(#imageLiteral(resourceName: "a3")),(#imageLiteral(resourceName: "a2")),(#imageLiteral(resourceName: "b2")),(#imageLiteral(resourceName: "b4")),(#imageLiteral(resourceName: "b5")),(#imageLiteral(resourceName: "b3")),(#imageLiteral(resourceName: "b1")),(#imageLiteral(resourceName: "fl3")),(#imageLiteral(resourceName: "fl5")),(#imageLiteral(resourceName: "fl4")),(#imageLiteral(resourceName: "fl1")),(#imageLiteral(resourceName: "fl2")),(#imageLiteral(resourceName: "f4")),(#imageLiteral(resourceName: "f1")),(#imageLiteral(resourceName: "f3")),(#imageLiteral(resourceName: "f2")),(#imageLiteral(resourceName: "f5")),(#imageLiteral(resourceName: "t1")),(#imageLiteral(resourceName: "t2")),(#imageLiteral(resourceName: "t5")),(#imageLiteral(resourceName: "t3")),(#imageLiteral(resourceName: "t4"))]
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell1", for: indexPath) as! Cell1
        
        
        
        
        
        
        return cell
    }

}

