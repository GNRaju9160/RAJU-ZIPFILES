//
//  CollectionViewCell2.swift
//  CollectionView
//
//  Created by Training on 01/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class CollectionViewCell2: UICollectionViewCell {
    
    @IBOutlet weak var imgFood: UIImageView!
    @IBOutlet weak var lblText: UILabel!
}
