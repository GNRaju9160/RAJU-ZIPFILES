//
//  CRcell.swift
//  CollectionVHeadPrac
//
//  Created by Training on 11/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class CRcell: UICollectionReusableView {
        
    @IBOutlet weak var lblText: UILabel!
    
    
}
