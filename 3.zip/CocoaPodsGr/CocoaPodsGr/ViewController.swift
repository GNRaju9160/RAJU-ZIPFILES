//
//  ViewController.swift
//  CocoaPodsGr
//
//  Created by Training on 24/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit
import DWAnimatedLabel
import SVProgressHUD
class ViewController: UIViewController {
    @IBOutlet weak var lblProfile: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        SVProgressHUD.show()
        Timer.scheduledTimer(withTimeInterval: 5, repeats: false) { (timer)
            in
            SVProgressHUD.dismiss()
        // Do any additional setup after loading the view.
    }


}
 }
