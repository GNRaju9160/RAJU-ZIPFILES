//
//  ViewController.swift
//  CurrentLocationMap
//
//  Created by Training on 20/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController,MKMapViewDelegate, CLLocationManagerDelegate  {
    
    @IBOutlet weak var mapKitView: MKMapView!
    let locationManager = CLLocationManager()
    var mapView:MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.locationManager.requestAlwaysAuthorization()
        
        // For use in foreground
        self.locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation()
        }
        
        mapKitView.delegate = self
        mapKitView.mapType = .standard
        mapKitView.isZoomEnabled = true
        mapKitView.isScrollEnabled = true
        
        if let coor = mapKitView.userLocation.location?.coordinate{
            mapKitView.setCenter(coor, animated: true)
        }
        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            let locValue:CLLocationCoordinate2D = manager.location!.coordinate
            
            mapKitView.mapType = MKMapType.standard
            
            let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
            let region = MKCoordinateRegion(center: locValue, span: span)
            mapKitView.setRegion(region, animated: true)
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = locValue
            annotation.title = "Mohali"
            annotation.subtitle = "current location"
            mapKitView.addAnnotation(annotation)
            
          
        }
    }


}

