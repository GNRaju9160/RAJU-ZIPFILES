//
//  ViewController.swift
//  CreateDataCoreData
//
//  Created by Training on 08/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    @IBOutlet weak var txtFldText: UITextField!
    @IBOutlet weak var txtFldMobile: UITextField!
    @IBOutlet weak var txtCity: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func btnSave(_ sender: Any) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let Context = appDelegate.persistentContainer.viewContext
        
        let newUser = NSEntityDescription.insertNewObject(forEntityName: "Users", into: Context)
        newUser.setValue(txtFldText.text, forKey: "userName")
        newUser.setValue(txtFldMobile.text, forKey: "mobile")
        newUser.setValue(txtCity.text, forKey: "city")
       
        do {
            try Context.save()
            print("Context Saved")
        } catch {
            print("Error: Not Saved")
            
        }
    }
    
    @IBAction func btnInfo(_ sender: Any) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let Context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        
        request.returnsObjectsAsFaults = false
        do {
            let results = try Context.fetch(request)
            if results.count > 0 {
                for r in results as! [NSManagedObject] {
                    if let userName = r.value(forKey: "useName") as? String {
                        print(userName)
                    }
                }
            }
            
        } catch {
            
        }
        
    }
    
}
