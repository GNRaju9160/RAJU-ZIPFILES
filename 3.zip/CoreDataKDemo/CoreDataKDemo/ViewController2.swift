

import UIKit
import CoreData


class ViewController2: UIViewController {
   
    
    
    
    @IBOutlet var lblName : UILabel!
    @IBOutlet var lblMobile : UILabel!
    
   
    var itemsName : [NSManagedObject] = []
    var itemsName2 : [NSManagedObject] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let appD = UIApplication.shared.delegate as! AppDelegate
        
        let context = appD.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Users")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        
        let fetchRequest2 = NSFetchRequest<NSManagedObject>(entityName: "Users")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "mobile", ascending: true)]
        
        do {
            itemsName = try context.fetch(fetchRequest)
            itemsName2 = try context.fetch(fetchRequest2)
            if let name = itemsName[0].value(forKey: "name") {
                lblName.text = (name as! String)
            }
            if let mobile = itemsName2[0].value(forKey: "mobile") {
                lblMobile.text = (mobile as? String)
            }
            
            
        }catch {
            print("")
        }
    }

}
    



