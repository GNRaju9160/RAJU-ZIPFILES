
import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet var txtFldName : UITextField!
    @IBOutlet var txtFldMobile : UITextField!
    
    
    @IBAction func save(){
        
        let appD = UIApplication.shared.delegate as! AppDelegate
        
        let context = appD.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Users", in : context)!
        
        let theTitle = NSManagedObject(entity: entity, insertInto: context)
        theTitle.setValue(txtFldName.text, forKey: "name")
        theTitle.setValue(txtFldMobile.text, forKey: "mobile")
        
        
        do {
            try context.save()
        }
        catch {
            print("Not save")
            
        }
    }
    
    @IBAction func actShowList(_ sender: Any) {
        let nextVC = self.storyboard?.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
        
       self.navigationController?.pushViewController(nextVC, animated: true)
        
    }
}




