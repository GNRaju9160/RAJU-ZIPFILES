//
//  CollectionViewCell.swift
//  CollectionViewDataTrans
//
//  Created by Training on 03/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgVw: UIImageView!
    @IBOutlet weak var lblText: UILabel!
    
}
