//
//  ViewController2.swift
//  CollectionViewDataTrans
//
//  Created by Training on 03/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    @IBOutlet weak var imgTour: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblToursPrice: UILabel!
    
    
    var selectedImage:UIImage!
    var selectedTourName:String!
    var selectedToursPrice:String!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imgTour.image = selectedImage
        lblName.text = selectedTourName
        lblToursPrice.text = selectedToursPrice
        

        // Do any additional setup after loading the view.
    }
    
    @IBAction func moveToAction(_ sender: Any) {
    }
  
    
    }
