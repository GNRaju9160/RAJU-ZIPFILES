//
//  ViewController.swift
//  CocoaPodG
//
//  Created by Training on 23/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  //  @IBOutlet weak var lblText: UILabel!
   // pod "LabelSwitch"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
//    let ls = LabelSwitchConfig(text: "Text1",
//                               textColor: .white,
//                               font: UIFont.boldSystemFont(ofSize: 15),
//                               backgroundColor: .red)
//
//    let rs = LabelSwitchConfig(text: "Text2",
//                               textColor: .white,
//                               font: UIFont.boldSystemFont(ofSize: 20),
//                               backgroundColor: .green)
//
//    // Set the default state of the switch,
//    let labelSwitch = LabelSwitch(center: .zero, leftConfig: ls, rightConfig: rs)
//
//    // Set the appearance of the circle button
//    labelSwitch.circleShadow = false
//    labelSwitch.circleColor = .red
//
//    // Make switch be triggered by tapping on any position in the switch
//    labelSwitch.fullSizeTapEnabled = true
//
//    // Set the delegate to inform when the switch was triggered
//    labelSwitch.delegate = self
//
//    extension ViewController: LabelSwitchDelegate {
//        func switchChangToState(sender: LabelSwitch) {
//            switch sender.curState {
//            case .L: print("circle on left")
//            case .R: print("circle on right")
//            }
//        }
    }




