//
//  ViewController.swift
//  SlideWithotPod
//
//  Created by Training on 24/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        addSlideMenuButton()
    }


}

