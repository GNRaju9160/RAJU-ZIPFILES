//
//  MenuViewController.swift
//  SlideWithotPod
//
//  Created by Training on 24/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit
protocol SlideMenuDelegate {
    
    func slideMenuItemSelectedIndex(_ index : Int32)
    
}
class MenuViewController: UIViewController {
  // ,UITableViewDelegate,UITableViewDataSource
    
    @IBOutlet weak var btnCloseTap: UIButton!
    var btnMenu : UIButton!
    var delegate : SlideMenuDelegate?
//    var arrNames = ["Home","Profile","Settings","Changepass"]
//    var arrImg = [(#imageLiteral(resourceName: "Home")),(#imageLiteral(resourceName: "Profile")),(#imageLiteral(resourceName: "Settings")),(#imageLiteral(resourceName: "ChangePass "))]
//
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//         return arrNames.count
//    }
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as! TableViewCell
//        cell.imgVw.image = arrImg[indexPath.row]
//        cell.lblText.text = arrNames[indexPath.row]
//
//        return cell
//    }
    
    
    @IBAction func btnCloseMenu(_ sender: Any) {
      
        
//        btnMenu.tag = 0
//        btnMenu.isHidden = false
//        if(self.delegate != nil) {
//            var index = Int32((sender as AnyObject).tag)
     //          if(sender == self.btnCloseTap){
      //      index = -1
    //    }
   //         delegate?.slideMenuItemSelectedIndex(index)
        
//        UIView.animate(withDuration: 0.3, animations: {(_) -> void in)
//            self.viewframe = CGRect(x: -UIScreen.main.bounds.size.width, y = 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
//            self.view.layoutIfNeeded()
//            self.view.backgroundColor = UIColor.clear
            
    //    },completion: {(finished) -> void in
       //     self.view.removeFrom.Superview()
      //      self.removeFromParent()
      //  })
    
    
    
//        }
}

}
