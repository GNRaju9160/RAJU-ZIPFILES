//
//  HeaderFooterCell.swift
//  TableViewH&F
//
//  Created by Training on 27/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class HeaderFooterCell: UITableViewCell {

    @IBOutlet weak var lblText: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
