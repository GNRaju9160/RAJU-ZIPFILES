//
//  ViewController2.swift
//  TabbarViewController
//
//  Created by Training on 21/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController2: UIViewController,UITabBarControllerDelegate {
 var tabBarCnt: UITabBarController!
    override func viewDidLoad() {
        super.viewDidLoad()

        createTabBarController()
        // Do any additional setup after loading the view.
    }
    func createTabBarController() {
        tabBarCnt = UITabBarController()
        tabBarCnt.delegate = self
        tabBarCnt.tabBar.barStyle = .blackOpaque
        
        
        
        let firstViewController = UIViewController()
        firstViewController.title = "Contacts"
        firstViewController.view.backgroundColor = #colorLiteral(red: 0.05882352963, green: 0.180392161, blue: 0.2470588237, alpha: 1)
        
        let secondViewController = UIViewController()
        secondViewController.title = "Bookmarks"
        secondViewController.view.backgroundColor = #colorLiteral(red: 0.1294117719, green: 0.2156862766, blue: 0.06666667014, alpha: 1)
        
        let thirdViewController = UIViewController()
        thirdViewController.title = "History"
        thirdViewController.view.backgroundColor = #colorLiteral(red: 0.4392156899, green: 0.01176470611, blue: 0.1921568662, alpha: 1)
        
        let fourthViewController = UIViewController()
        fourthViewController.title = "Search"
        fourthViewController.view.backgroundColor = #colorLiteral(red: 0.5058823824, green: 0.3372549117, blue: 0.06666667014, alpha: 1)
        
        
        tabBarCnt.viewControllers = [firstViewController,secondViewController,thirdViewController,fourthViewController]
        
        self.view.addSubview(tabBarCnt.view)
        
    }
    

  

}
