//
//  ViewController.swift
//  TabbarViewController
//
//  Created by Training on 21/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldPass: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func btnLogin(_ sender: Any) {
        let nextVC = self.storyboard?.instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
        nextVC.name = txtFldName.text
     
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
        
}
   
