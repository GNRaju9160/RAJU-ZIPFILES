//
//  ProfileVC.swift
//  TabbarViewController
//
//  Created by Training on 21/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ProfileVC: UIViewController,UITabBarDelegate {
    
    
    
    @IBOutlet weak var lblName: UILabel!
  
    var name : String!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func btnLogout(_ sender: Any) {
    self.navigationController?.popViewController(animated: true)
    }

    
    
    
    

}
