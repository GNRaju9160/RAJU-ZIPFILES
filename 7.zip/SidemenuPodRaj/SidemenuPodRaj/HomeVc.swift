//
//  HomeVc.swift
//  SidemenuPodRaj
//
//  Created by Training on 29/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class HomeVc: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func btnHome(_ sender: Any) {
       

        
    }
    


}
