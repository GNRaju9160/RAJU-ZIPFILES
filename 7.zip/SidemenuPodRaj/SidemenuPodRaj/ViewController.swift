
import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    @IBOutlet weak var tblVw: UITableView!
    
    var arrNames = ["Home","Profile","Settings","Password"]
    var arrImg = [(#imageLiteral(resourceName: "Home")),(#imageLiteral(resourceName: "Profile")),(#imageLiteral(resourceName: "Settings")),(#imageLiteral(resourceName: "Password"))]
    var segueIdentifier = ["HomeVc","ProfileVc","SettingsVc","ChangePassVc"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return arrNames.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as! TableViewCell
        cell.imgVwCell.image = arrImg[indexPath.row]
        cell.lblTextCell.text = arrNames[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc = segueIdentifier[indexPath.row]
        let homeVc = storyboard?.instantiateViewController(withIdentifier: vc)
        self.navigationController?.pushViewController(homeVc!, animated: true)
}
}
