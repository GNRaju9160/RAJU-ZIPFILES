//
//  ViewController2.swift
//  TabBarDataTrans
//
//  Created by Training on 21/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
  
    @IBOutlet weak var txtFldName2: UITextField!
    
    @IBOutlet weak var txtFldPass: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func btnLogin(_ sender: Any) {
        let nextVC = storyboard?.instantiateViewController(withIdentifier: "ViewController4") as! ViewController4
        nextVC.selectedName2 = txtFldName2.text!
        self.navigationController?.pushViewController(nextVC, animated: true)
        
        
        
    }
    


}
