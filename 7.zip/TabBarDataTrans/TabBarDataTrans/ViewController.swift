//
//  ViewController.swift
//  TabBarDataTrans
//
//  Created by Training on 21/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var imgVw: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func btnTRans1(_ sender: Any) {
      let nextVC = storyboard?.instantiateViewController(withIdentifier: "ViewController3") as! ViewController3
        nextVC.selectedName = txtFldName.text!
        nextVC.selectedImage = imgVw.image!
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    

}

