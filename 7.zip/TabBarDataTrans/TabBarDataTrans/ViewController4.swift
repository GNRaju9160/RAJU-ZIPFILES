//
//  ViewController4.swift
//  TabBarDataTrans
//
//  Created by Training on 21/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController4: UIViewController {
    @IBOutlet weak var lblName2: UILabel!
    var selectedName2 = ""
    override func viewDidLoad() {
        super.viewDidLoad()
lblName2.text = selectedName2
        // Do any additional setup after loading the view.
    }
    

   
}
