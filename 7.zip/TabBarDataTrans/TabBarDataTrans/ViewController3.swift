//
//  ViewController3.swift
//  TabBarDataTrans
//
//  Created by Training on 21/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController3: UIViewController {
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgVw2: UIImageView!
    
    var selectedName = ""
    var selectedImage = UIImage()
    override func viewDidLoad() {
        super.viewDidLoad()
lblName.text = selectedName
 imgVw2.image = selectedImage
        // Do any additional setup after loading the view.
    }
    @IBAction func btnCLick3(_ sender: Any) {
       let nextVC = storyboard?.instantiateViewController(withIdentifier: "ViewController5") as! ViewController5
        nextVC.selectedName2 = lblName.text!
         nextVC.selectedImage5 = imgVw2.image!
        
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    

  
}
