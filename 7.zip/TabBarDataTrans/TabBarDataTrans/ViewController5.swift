//
//  ViewController5.swift
//  TabBarDataTrans
//
//  Created by Training on 22/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController5: UIViewController {
    @IBOutlet weak var txtFldName5: UITextField!
    @IBOutlet weak var imgVw5: UIImageView!
    var selectedName2 = ""
    var selectedImage5 = UIImage()
    override func viewDidLoad() {
        super.viewDidLoad()
        txtFldName5.text = selectedName2
        imgVw5.image = selectedImage5
        // Do any additional setup after loading the view.
    }
    
    
    
}
