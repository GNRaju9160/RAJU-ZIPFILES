
import UIKit
import MapKit

class ViewController: UIViewController {
    
    @IBOutlet weak var MapkitView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }


}

