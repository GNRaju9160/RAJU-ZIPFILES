//
//  HomeVC.swift
//  SideMenuKR
//
//  Created by Training on 07/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class HomeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func btnMenu(_ sender: Any) {
//        let nextVC = storyboard?.instantiateViewController(withIdentifier: "MenuVC") as! MenuVC
//        nextVC.navigationController?.pushViewController(nextVC, animated: true)
    }
    


}
