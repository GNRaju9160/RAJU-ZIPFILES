//
//  SettingsVC.swift
//  SideMenuKR
//
//  Created by Training on 07/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class SettingsVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}
