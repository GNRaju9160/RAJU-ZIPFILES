//
//  ViewController.swift
//  SegmentsNumLetters
//
//  Created by Training on 06/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var redSlider: UISlider!
    @IBOutlet weak var greenSlider: UISlider!
    @IBOutlet weak var blueSlider: UISlider!
    @IBOutlet weak var txtFldText: UITextField!
    @IBOutlet weak var lblRed: UILabel!
    @IBOutlet weak var lblGreen: UILabel!
    @IBOutlet weak var lblBlue: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
 
        
    }
    @IBAction func actionSliders(_ sender: Any) {
    
   txtFldText.textColor = UIColor(red: CGFloat(redSlider.value/255), green: CGFloat(greenSlider.value/255), blue: CGFloat(blueSlider.value/255), alpha: 1)
        
    }
    
        
    }
