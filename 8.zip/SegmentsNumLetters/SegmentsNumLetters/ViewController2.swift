//
//  ViewController2.swift
//  SegmentsNumLetters
//
//  Created by Training on 06/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    @IBOutlet weak var tblVwNum: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnEven(_ sender: Any) {
        
    }
    
    @IBAction func btnOdd(_ sender: Any) {
    }
    
    @IBAction func btnLetters(_ sender: Any) {
    }
    
}
