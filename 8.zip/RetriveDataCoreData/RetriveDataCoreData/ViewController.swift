

import UIKit
import CoreData
class ViewController: UIViewController  {
    
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldMobile: UITextField!
    @IBOutlet weak var txtFldCity: UITextField!
//    var i = Int()
//    var isUpdate = Bool()
    
    override func viewDidLoad() {
        super.viewDidLoad()
//    }
//    func retriveData() {
//        let appDelegate = UIApplication.shared.delegate as! AppDelegate
//        let Context = appDelegate.persistentContainer.viewContext
//        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
//        do {
//            let Result = try managedContext.fetch(fetchRequest)
//            for data in Result as! [NSManagedObject] {
//            print(data.value(forkey: "userName") as! String)
//            
//            }
//        }catch{
//            print ("Failed")
//        }
      }
    @IBAction func btnSave(_ sender: Any) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let Context = appDelegate.persistentContainer.viewContext
        let newUser = NSEntityDescription.insertNewObject(forEntityName: "Users", into: Context)
        newUser.setValue(txtFldName.text, forKey: "userName")
        newUser.setValue(txtFldMobile.text, forKey: "mobile")
        newUser.setValue(txtFldCity.text, forKey: "city")
        
        do {
            try Context.save()
            print("Context Saved")
        } catch {
            print("Error: Not Saved")
            
        }
    }
    
    @IBAction func btnShowlist(_ sender: Any) {
       
            let nextVC = storyboard?.instantiateViewController(withIdentifier: "ShowlistVC") as! ShowlistVC
            self.navigationController?.pushViewController(nextVC, animated: true)
            
        }
        
    }
