
import UIKit
import CoreData
protocol DataPass {
    func data(object:[String:String], index:Int, isEdit: Bool)
}

class ShowlistVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tblVwUserlist: UITableView!
    var details = [Users]()
    var delegate: DataPass!
    
    override func viewDidLoad() {
       
       var itemsName = try context.fetch(fetchRequest)
        var lblName: String = ""
        var lblCity: String = ""
        for item in itemsName {
            if let score = item.value(forKey: "score") as? String {
                mergedScore.append(score)
                mergedScore.append(" ") //separator
            }
            if let alba = item.value(forKey: "alba") as? String {
                mergedScore.append(alba)
                mergedScore.append(" ") //separator
            }
        }
        lblName.text =
        lblCity.text = mergedAlba
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return details.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailTVC") as! DetailTVC
        
        cell.lblName?.text = details[indexPath.row].userName
        cell.lblMobile?.text = details[indexPath.row].mobile
        cell.lblCity?.text = details[indexPath.row].city
        return cell
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath){
        if(editingStyle == UITableViewCell.EditingStyle.delete){
            
        }
    }
    
}
//        retriveData()
//
//    }
//
//    func retriveData() {
// super.viewDidLoad()
//let appDelegate = UIApplication.shared.delegate as! AppDelegate
//let Context = appDelegate.persistentContainer.viewContext
//let requestData = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
//let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
//do {
//    let Result = try FetchManagedObjectFromDatabaseForStoreData(Entity: Users!)
//
//    for data in Result as! [NSManagedObject] {
//        print(data.value(forkey: "userName") as! String)
//    }
//}catch{
//    print ("Failed")
//}

