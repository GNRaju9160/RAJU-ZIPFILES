//
//  ViewController.swift
//  BarBtnTabPrograme
//
//  Created by Training on 22/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(tapButton))
        self.navigationItem.leftBarButtonItem = addButton
        
        
        
        
        
        let searchButton = UIBarButtonItem(barButtonSystemItem: .search, target: self, action: #selector(tapButton))
        
        let cameraButton1 = UIBarButtonItem(barButtonSystemItem: .camera, target: self, action: #selector(tapButton))
      //  let cameraButton2 = UIBarButtonItem(title: "camera", style: .done, target: self, action: #selector(tapButton))
//    self.navigationItem.rightBarButtonItems = [cameraButton1, cameraButton2]
      // self.navigationItem.rightBarButtonItem = cameraButton1
        
        self.navigationItem.rightBarButtonItems = [searchButton, cameraButton1]
        
        
    }
    @objc func tapButton() {
        
    
}

}
