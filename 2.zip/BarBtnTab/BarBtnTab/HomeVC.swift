//
//  HomeVC.swift
//  BarBtnTab
//
//  Created by Training on 22/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class HomeVC: UIViewController {
    @IBOutlet weak var lblText: UILabel!
    
    @IBOutlet weak var imgVw: UIImageView!
    
    var selectedName = ""
   
    override func viewDidLoad() {
        super.viewDidLoad()
        lblText.text = selectedName
      

        // Do any additional setup after loading the view.
    }
    @IBAction func btnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnProfile(_ sender: Any) {
        let nextVC = storyboard?.instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
        
        nextVC.selectedImage = imgVw.image!
        
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    @IBAction func btnSearch(_ sender: Any) {
        let nextVC = storyboard?.instantiateViewController(withIdentifier: "SearchVC") as! SearchVC
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    

}
