//
//  SearchVC.swift
//  BarBtnTab
//
//  Created by Training on 22/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit
import WebKit
class SearchVC: UIViewController {
    
    @IBOutlet weak var webView: WKWebView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let url = URL(string: "https://www.google.com")!
        webView.load(URLRequest(url: url))
    }
    
    @IBAction func btnBack(_ sender: Any) {
        if webView.canGoBack {
            webView.goBack()
        }
    }
    
    
    
    @IBAction func btnForword(_ sender: Any) {
        if webView.canGoForward {
            webView.goForward()
        }
    }
    
    @IBAction func btnRefresh(_ sender: Any) {
        webView.reload()
        
    }
    
    @IBAction func btnStop(_ sender: Any) {
        webView.stopLoading()
    }
}
