//
//  ViewController.swift
//  BarBtnTab
//
//  Created by Training on 22/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var txtFldName: UITextField!
    
    @IBOutlet weak var txtFldPass: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func btnMove(_ sender: Any) {
        let nextVC = storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
        nextVC.selectedName = txtFldName.text!
        
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    

}

