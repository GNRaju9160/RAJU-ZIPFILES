//
//  VCimage3.swift
//  AlertViewR
//
//  Created by Training on 19/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class VCimage3: UIViewController {
    @IBOutlet weak var imgApple: UIImageView!
    @IBOutlet weak var imgEarth: UIImageView!
    @IBOutlet weak var imgUmbrilla: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        addGesture()
//       
//    }
//    func addGesture() {
//        let tap = UITapGestureRecognizer(target: self, action: #selector(Vie)?)

    }
}
