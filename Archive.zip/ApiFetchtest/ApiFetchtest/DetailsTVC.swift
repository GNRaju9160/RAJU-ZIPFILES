//
//  DetailsTVC.swift
//  ApiFetchtest
//
//  Created by Training on 15/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class DetailsTVC: UITableViewCell {
    @IBOutlet weak var lblId: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblStreet: UILabel!
    @IBOutlet weak var lblSuite: UILabel!
    @IBOutlet weak var lblCity: UILabel!
    @IBOutlet weak var lblZipCode: UILabel!
    @IBOutlet weak var lblLat: UILabel!
    @IBOutlet weak var lblLag: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
