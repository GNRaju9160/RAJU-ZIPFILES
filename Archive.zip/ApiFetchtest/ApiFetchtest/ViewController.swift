
import UIKit
import Alamofire
class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tblUserList: UITableView!
    var dict = [NSDictionary]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = "https://jsonplaceholder.typicode.com/users"
        Alamofire.request(url).responseJSON{(Data) in
            if let getDict = Data.result.value{
                self.dict = getDict as! [NSDictionary]
                self.tblUserList.reloadData()
                print(getDict)
            }else{
                print("error")
            }
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dict.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailsTVC", for: indexPath) as! DetailsTVC
        cell.lblId.text = ("\(dict[indexPath.row]["id"] ?? "error")")
        cell.lblName.text = ("\(dict[indexPath.row]["name"] ?? "error")")
        cell.lblUserName.text = ("\(dict[indexPath.row]["username"] ?? "error")")
        cell.lblEmail.text = ("\(dict[indexPath.row]["email"] ?? "error")")
        
        let addressDict = dict[indexPath.row]["address"] as? NSDictionary
        cell.lblStreet.text = ("\(addressDict!["street"] ?? "error")")
        cell.lblSuite.text = ("\(addressDict!["suite"] ?? "error")")
        cell.lblCity.text = ("\(addressDict!["city"] ?? "error")")
        cell.lblZipCode.text = ("\(addressDict!["zipcode"] ?? "error")")
        
        let geoDict = addressDict!["geo"] as? NSDictionary
        cell.lblLat.text = ("\(geoDict!["lat"] ?? "error")")
        cell.lblLag.text = ("\(geoDict!["lng"] ?? "error")")
        
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 680
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
}

