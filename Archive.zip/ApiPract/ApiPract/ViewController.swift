//
//  ViewController.swift
//  ApiPract
//
//  Created by Training on 01/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit
import JSON
import Alomofire

class ViewController: UIViewController {
 let url = "https://swapi.co/api/people/"
    override func viewDidLoad() {
        super.viewDidLoad()
      
    
    hitApi()
}
func hitApi(){
    Alamofire.request(url).responseJSON{response in
        guard let json = response.result.value as? [String: Any]
            else {
                print("JSON not found")
                print("Error:\(response.result.value)")
                return
        }
        print(json)
    }
    

}

}
