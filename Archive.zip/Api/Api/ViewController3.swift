
import UIKit
import Alamofire
class ViewController3: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    @IBOutlet weak var tblVw: UITableView!
    let url = "https://jsonplaceholder.typicode.com/comments"
    var arrName = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        hitApi()
    }
    func hitApi(){
        Alamofire.request(url).responseJSON{response in
            guard let json = response.result.value as? [String: Any]
                else {
                    print("JSON not found")
                    print("Error:\(String(describing: response.result.value))")
                    return
            }
            print(json)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblVw.dequeueReusableCell(withIdentifier: "TableViewCell") as! TableViewCell
        
        return cell
    }
    
}
