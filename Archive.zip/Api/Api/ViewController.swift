import UIKit
import Alamofire
class ViewController: UIViewController {
  //  let url = "http://reqres.in/api/users?page=2"
   let url = "https://jsonplaceholder.typicode.com/comments"
   // let url = "https://swapi.co/api/people/"
    override func viewDidLoad() {
        super.viewDidLoad()
      hitApi()
    }
    func hitApi(){
        Alamofire.request(url).responseJSON{response in
            guard let json = response.result.value as? [String: Any]
                else {
                    print("JSON not found")
                    print("Error:\(String(describing: response.result.value))")
                    return
            }
            print(json)
        }

    }

    }
