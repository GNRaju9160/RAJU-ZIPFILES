
import UIKit
import Alamofire
class ViewController2: UIViewController {
    
    @IBOutlet weak var lblBody: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblId: UILabel!
    @IBOutlet weak var lblName: UILabel!
    
    let url = "https://jsonplaceholder.typicode.com/comments"
    var arrData = NSMutableArray()
    let dictData = NSMutableDictionary()
    
       override func viewDidLoad() {
        super.viewDidLoad()
        
        dictData.setValue(lblName.text, forKey: "name" )
        dictData.setValue(lblEmail.text, forKey: "email" )
        dictData.setValue(lblId.text, forKey: "id" )
        dictData.setValue(lblBody.text, forKey: "body" )
        
        hitApi()
    }
    
    func getData (url:String) {
        
    }
    
    func hitApi(){
        
        func postApi(url:String, postPaaram: [String: Any]) {
           Alamofire.request(url).responseJSON{response in
                guard let json = response.result.value as? [String: Any]
                    else {
                        //    print("JSON not found")
                        //  print("Error:\(String(describing: response.result.value))")
                        return
                }
                print(json)
                
                if let dictData = response.result.value as? NSDictionary {
                    
                    if let jsonData = dictData["json"] as? NSDictionary{
                        self.lblName.text = jsonData.value(forKey: "name") as? String
                        self.lblEmail.text = jsonData.value(forKey: "email") as? String
                        self.lblId.text = jsonData.value(forKey: "id") as? String
                        self.lblBody.text = jsonData.value(forKey: "body") as? String
                     }
                    let urlString = dictData["url"] as? String
                    self.lblId.text = urlString
                }
            }
          }
    }
}
