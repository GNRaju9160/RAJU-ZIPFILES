//
//  DetailsTVC.swift
//  APiPractice
//
//  Created by Training on 07/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class DetailsTVC: UITableViewCell {
    @IBOutlet weak var lblUser: UILabel!
    @IBOutlet weak var lblId: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblBody: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
