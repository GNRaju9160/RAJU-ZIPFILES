
import UIKit

import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet weak var tblVw: UITableView!
    let urlStr = "https://jsonplaceholder.typicode.com/posts"
    var arrReselut = [Users]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        callApi()
        func callApi() {
            
            let url = URL(string: urlStr)
            Alamafire.request(url!, method: .get, parameters:nil, headers: nil).responseJSON {(response) in
                if let responseObj = response.value as? [[String: Any]] {
                    self.arrReselut = self.parseJSON(userData: responseObj)
                    self.tblVw.reloadData()
                    print(self.arrReselut)
                }
            }
        }
        func pareseJSON(userData: [[String: Any]]) -> [Users] {
            
            var arrUser = [Users]()
            for obj in userData {
                do {
                    var userObj = Users()
                    userObj.detailsUser(obj)
                    arrUser.append(userObj)
                } catch {
                }
            }
             return arrUser
        }
    }
}

extension ViewController: UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrReselut.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailsTVC") as! DetailsTVC
        cell.lblUser?.text = arrResult[indexPath.row].userid
        cell.lblId?.text = "\(arrResult[indexpath.row].Id)"
        cell.lblTitle?.text = arrResult[indexPath.row].title
        cell.lblBody?.text = arrResult[indexPath.row].body
    }
}
