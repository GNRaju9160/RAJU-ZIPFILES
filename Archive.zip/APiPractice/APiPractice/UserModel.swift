//
//  UserModel.swift
//  APiPractice
//
//  Created by Training on 07/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import Foundation
class Users: NSObject {
    
    var userid = String()
    var id = Int()
    var body = String()
    var title = String()
    
    func detailsUser(_ data:[String: Any]) {
        userid = data["userid"] as? String ?? "No User id"
        id = data["id"] as? Int ?? 0
        body = data["body"] as? String ?? "No Boby"
        title = data["title"] as? String ?? "No Title"
    }
}
