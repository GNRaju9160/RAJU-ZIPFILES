import UIKit
class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var txtFldNumber: UITextField!
    @IBOutlet weak var tblVwList: UITableView!
    
    var arrData = NSMutableArray()
    var selectedItem = Int()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblVwList.isEditing = true
        self.tblVwList.allowsMultipleSelectionDuringEditing = true
    }
    
    @IBAction func btnAdd(_ sender: Any) {
        if  txtFldNumber.text! != "" {
            arrData.add(txtFldNumber.text!)
            tblVwList.reloadData()
            clearText()
        }
    }
    @IBAction func btnDelete(_ sender: Any) {
      //  arrData.removeObject(at: selectedItem)
        
        tblVwList.reloadData()
        clearText()
        tblVwList.isEditing = tblVwList.isEditing
    }
    func clearText()
    {
        txtFldNumber.text = ""
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AddDeleteTVC", for: indexPath) as! AddDeleteTVC
        cell.textLabel?.text = arrData[indexPath.row] as? String
        //  cell.textLabel!.text = arrData[indexPath.row] as! String
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedItem = indexPath.row
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .insert {
            self.arrData.removeObject(at: indexPath.row)
            self.tblVwList.reloadData()
        }
        
        
    }
}
