import UIKit

class ListTVC: UITableViewCell {

    
    
    @IBOutlet weak var lblId: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet weak var lblAdress: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblZip: UILabel!
    @IBOutlet weak var lblCity: UILabel!
    @IBOutlet weak var lblSuite: UILabel!
    @IBOutlet weak var lblStreet: UILabel!
   
    @IBOutlet weak var lblGeo: UILabel!
    @IBOutlet weak var lblLat: UILabel!
    @IBOutlet weak var lblLag: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
