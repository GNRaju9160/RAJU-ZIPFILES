

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imgVw: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let imageURL = NSURL(string: "https://httpbin.org/image/png")
        let imagedData = NSData(contentsOf: imageURL! as URL)!
        imgVw?.image = UIImage(data: imagedData as Data)
       
    }
}


//   "https://httpbin.org/image/png"

//   "https://farm2.staticflickr.com/1591/26078338233_d1466b7da2_m.jpg"
// "https://i.imgur.com/ONaprQV.png"
//func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
//
//    let cell = tableView.dequeueReusableCellWithIdentifier("theCell", forIndexPath: indexPath) as! customTableViewCell
//
//    let imageURL = NSURL(string: "https://farm2.staticflickr.com/1591/26078338233_d1466b7da2_m.jpg")
//
//    let imagedData = NSData(contentsOfURL: imageURL!)!
//
//    cell.imageView?.image = UIImage(data: imagedData)
//
//    return cell
//
//}
//getImageFromWeb("http://www.apple.com/euro/ios/ios8/a/generic/images/og.png") { (image) in
//    if let image = image {
//        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 200, height: 200))
//        imageView.image = image
//        self.view.addSubview(imageView)
//    } // if you use an Else statement, it will be in background
//}
