//
//  ViewController2.swift
//  PushandPop
//
//  Created by Training on 27/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func backtoAction(_ sender: Any) {
//
//    self.navigationController?.popToRootViewController(animated: true)
   
        self.navigationController?.popViewController(animated: true)
}

    @IBAction func moveAction(_ sender: Any) {
        
//      self.navigationController?.popViewController(animated: true)
//
        
        
        
        
  let moveToNextObj = self.storyboard?.instantiateViewController(withIdentifier:  "ViewController3") as! ViewController3

     self.navigationController?.pushViewController(moveToNextObj, animated: true)

    }
    
}

