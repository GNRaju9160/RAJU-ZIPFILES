//
//  ViewController7.swift
//  PushandPop
//
//  Created by Training on 30/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController7: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    

    let sectionArr = ["Contacts"]
    
    var itemsArr = ["Raju","Gopal","Kishore"]
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemsArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell1") as! TableViewCell1
        cell.lblText.text = itemsArr[indexPath.row]
        return cell

    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
        let secVc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController8") as! ViewController8
        secVc.textStr = itemsArr[indexPath.row]
        
        self.navigationController?.pushViewController(secVc, animated: true)
        
        
    }

   // var titlevar = String()
    
}
