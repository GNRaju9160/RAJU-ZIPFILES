//
//  ViewController4.swift
//  PushandPop
//
//  Created by Training on 30/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController4: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func moveAction(_ sender: Any) {
    
  let moveToNextObj = self.storyboard?.instantiateViewController(withIdentifier: "ViewController6") as! ViewController6
       self.navigationController?.pushViewController(moveToNextObj, animated: true)
    }
    @IBAction func btnSignup(_ sender: Any) {
    
        let moveToNextObj = self.storyboard?.instantiateViewController(withIdentifier: "ViewController5") as! ViewController5
        self.navigationController?.pushViewController(moveToNextObj, animated: true)
    
    
    
    
    }
}
