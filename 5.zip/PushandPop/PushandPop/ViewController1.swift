//
//  ViewController1.swift
//  PushandPop
//
//  Created by Training on 27/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController1: UIViewController {

    @IBOutlet weak var lblVC1: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func moveAction(_ sender: Any) {
        
     let moveToNextObj =
        self.storyboard?.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
       self.navigationController?.pushViewController(moveToNextObj, animated: true)
        
        
        
        
        
        
//        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
//        self.navigationController?.pushViewController(secondVC, animated: true)
//    }
  

}
}
