//
//  ViewController5.swift
//  PushandPop
//
//  Created by Training on 30/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController5: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnAction(_ sender: Any) {
    self.navigationController?.popViewController(animated: true)
    
    
    
    
    }
    
}
