//
//  ViewController8.swift
//  PushandPop
//
//  Created by Training on 30/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController8: UIViewController {

    @IBOutlet weak var lblText2: UILabel!
    
    var textStr: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblText2.text = textStr

    }
    

   

}
