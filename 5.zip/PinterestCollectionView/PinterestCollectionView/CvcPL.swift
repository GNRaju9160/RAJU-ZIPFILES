
import UIKit

class CvcPL: UICollectionViewCell {
    @IBOutlet weak var imgVw: UIImageView!
    
}
