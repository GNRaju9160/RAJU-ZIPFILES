//
//  ViewController3.swift
//  TableViewTutorial
//
//  Created by Training on 24/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController3: UIViewController{
   
   let animalsArr = ["Lion","Tiger","Leopard","Horse",]

 let fruitsArr = ["Apple","Banana","Mango","Grapes"]
    
    
  let friendsArr = ["Gopal","Kishore","Vivek","Chandan","Siddh"]
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//     return animalsArr.count
//
//
//     return fruitsArr.count
//     return friendsArr.count
//    }
    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        return ce    }

}
