//
//  TableViewController.swift
//  practice
//
//  Created by Training on 24/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class TableViewController: UIViewController {

    @IBOutlet weak var tblvwList: UITableView!
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
 
}
