//
//  Delegate4ViewController.swift
//  practice
//
//  Created by Training on 20/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class Delegate4ViewController: UIViewController {
    
    @IBOutlet weak var dateText: UITextField!
    
    @IBAction func cancelButtonTapped(_ sender: UIButton) {
    }
    
    @IBAction func saveButtonTapped(_ sender: UIButton) {
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    

}
