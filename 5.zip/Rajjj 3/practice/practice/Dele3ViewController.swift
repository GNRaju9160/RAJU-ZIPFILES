//
//  Dele3ViewController.swift
//  practice
//
//  Created by Training on 20/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class Dele3ViewController: UIViewController,UITextFieldDelegate {
    @IBOutlet weak var lblSelect: UILabel!
    
    @IBOutlet weak var txtFld: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        txtFld.delegate = self
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        print("Allow editing")
         return true
    }
    
        func textFieldDidBeginEditing(_ textField: UITextField){
    }
            
      func textFieldShouldEndEditing(_ textField: UITextField) -> Bool{
        return false
    }
               
     func textFieldDidEndEditing(_ textField: UITextField){
       
    }
        func textFieldShouldReturn(_ textField: UITextField) -> Bool{
   return false
            
    }

    func textFieldShouldClear(_ textField: UITextField) -> Bool{
        return false
    }
                
            }


