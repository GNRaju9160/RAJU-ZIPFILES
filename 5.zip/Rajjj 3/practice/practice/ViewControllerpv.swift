//
//  ViewControllerpv.swift
//  practice
//
//  Created by Training on 23/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewControllerpv: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
        
    }
    
    
    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var pickerView: UIPickerView!
    
    let cities = ["Kurnool", "Thirupathi", "Vijayawada", "Srisailam", "Hyderabad", "Vizag", "Amaravathi", "Chithoore", "Ananthapuram", "Nellore", "Rajamundri", "Kakinada", "Srikakulam", "Vizayanagaram"]
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        
        
  override func didreceivememorywarning[]
        func numberComponents(in pickerview: UIPickerview) -> int
        {
        
            return 1
        }
       

}
}
