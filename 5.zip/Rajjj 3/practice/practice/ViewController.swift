//
//  ViewController.swift
//  practice
//
//  Created by Training on 20/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var inputTextField: UITextField!
    
    private var datepicker: UIDatePicker?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        datepicker = UIDatePicker()
        datepicker?.datePickerMode = .date
        datepicker?.addTarget(self, action: #selector(ViewController.dateChanged(datePicker:)),
                              for: .valueChanged)
        
      
       
        
        
        
        
        inputTextField.inputView = datepicker
    }
    
    @objc func dateChanged(datePicker: UIDatePicker) {
        view.endEditing(true)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/YYYY"
        inputTextField.text = dateFormatter.string(from: datepicker!.date)
        view.endEditing(true)
    }
        
        
        
        // Do any additional setup after loading the view.
    }
    


