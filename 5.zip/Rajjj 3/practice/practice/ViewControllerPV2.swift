//
//  ViewControllerPV2.swift
//  practice
//
//  Created by Training on 23/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewControllerPV2: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var cityPickerview: UIPickerView!
    @IBOutlet weak var lblCities: UILabel!
    
    @IBOutlet weak var img: UIImageView!
    
    
    let cities = ["Kurnool","Vijayawada","Thirupathi", "Hyderabad","Vizag","Srisailam","Chithoore","Nellore","Srikakulam","Vijayanagaram","Amaravathi","Rajamundry","Kakinada"]
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return cities[row]
        
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return cities.count
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
     
     //   lblCities.text = cities[row]
        
        
    }
    
    

override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
}
