//
//  delegate2ViewController.swift
//  practice
//
//  Created by Training on 20/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class delegate2ViewController: UIViewController,UITextFieldDelegate{
    @IBOutlet weak var lblWhatuwant: UILabel!
    
    @IBOutlet weak var txtField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            switch textField {
            case textField:
                textField.resignFirstResponder()
            default:
                break
            }
            return true
        }
        
        func txtFieldShouldEndEditing(_ textField: UITextField) -> Bool {
            return true
        }
    }
        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


