//
//  DELEViewController.swift
//  practice
//
//  Created by Training on 20/09/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class DELEViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtFld: UITextField!
    @IBOutlet weak var btnSubmit: UIButton!
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txtFld.resignFirstResponder()
        return true
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
      print("allow editing")
        return true
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        print("did begin editing method")
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        print("should end editing ")
    return true
}
    func textFieldDidEndEditing(_ textField: UITextField) {
     
        print(" did end editingmethod")
    }
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextField.DidEndEditingReason) {
        
        print("did end editing")
        
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        print("while entering the characters")
        return true
        
}

    func textFieldShouldClear(_ textField: UITextField) -> Bool {
    
        print("clear pressed")
        return true
    }
    
    }
    

