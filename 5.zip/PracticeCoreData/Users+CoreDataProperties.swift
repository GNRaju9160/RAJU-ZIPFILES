//
//  Users+CoreDataProperties.swift
//  PracticeCoreData
//
//  Created by Training on 08/11/19.
//  Copyright © 2019 Training. All rights reserved.
//
//

import Foundation
import CoreData


extension Users {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Users> {
        return NSFetchRequest<Users>(entityName: "Users")
    }

    @NSManaged public var name: String?
    @NSManaged public var mobile: String?
    @NSManaged public var city: String?
    @NSManaged public var computer: NSSet?

}

// MARK: Generated accessors for computer
extension Users {

    @objc(addComputerObject:)
    @NSManaged public func addToComputer(_ value: Users)

    @objc(removeComputerObject:)
    @NSManaged public func removeFromComputer(_ value: Users)

    @objc(addComputer:)
    @NSManaged public func addToComputer(_ values: NSSet)

    @objc(removeComputer:)
    @NSManaged public func removeFromComputer(_ values: NSSet)

}
