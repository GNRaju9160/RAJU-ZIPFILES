//
//  File.swift
//  PracticeCoreData
//
//  Created by Training on 08/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import Foundation
import CoreData

class DataController {
    // 1.
    let persistentContainer = NSPersistentContainer(name: "LibraryDataModel")
    
    func initalizeStack() {
        // 2.
        self.persistentContainer.loadPersistentStores { description, error in
            // 3.
            if let error = error {
                print("could not load store \(error.localizedDescription)")
                return
            }
            
            print("store loaded")
        }
    }
}
