//
//  ViewController.swift
//  PracticeCoreData
//
//  Created by Training on 08/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController {
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldMobile: UITextField!
    @IBOutlet weak var txtFldCity: UITextField!
    @IBOutlet weak var lblStatus: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnSave(_ sender: Any) {
        let appDelegateObject:AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedObject:NSManagedObjectContext = appDelegateObject.persistentContainer.viewContext
        let entityDescription =
            NSEntityDescription.entity(forEntityName: "users",
                                       in: managedObject)
        let student = NSManagedObject(entity: entityDescription!, insertInto: managedObject)
        [student .setValue(self.txtFldName.text, forKey: "name")]
        [student .setValue(self.txtFldMobile.text, forKey: "mobile")]
        [student .setValue(self.txtFldCity.text, forKey: "city")]
        lblStatus.text = "Contact Saved"
        
        
    }
    @IBAction func btnFind(_ sender: Any) {
        let appDelegateObject:AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedObject:NSManagedObjectContext = appDelegateObject.persistentContainer.viewContext
        let entityDescription =
            NSEntityDescription.entity(forEntityName: "users",
                                       in: managedObject)
        
        let request = NSFetchRequest<NSFetchRequestResult>()
        request.entity = entityDescription
        
        let pred = NSPredicate(format: "(name = %@)", txtFldName.text!)
        request.predicate = pred
        do {
            var results =
                try managedObject.fetch(request)
            
            if results.count > 0 {
                let match = results[0] as! NSManagedObject
                
                txtFldName.text = match.value(forKey: "name") as? String
                txtFldMobile.text = match.value(forKey: "mobile") as? String
                txtFldCity.text = match.value(forKey: "city") as? String
                lblStatus.text = "Matches found: \(results.count)"
            } else {
                lblStatus.text = "No Match"
            }
            
        } catch let error as NSError {
            
            
            lblStatus.text = error.localizedFailureReason
        }
    }
    
}
        



