//
//  Users+CoreDataClass.swift
//  PracticeCoreData
//
//  Created by Training on 08/11/19.
//  Copyright © 2019 Training. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Users)
public class Users: NSManagedObject {

}
