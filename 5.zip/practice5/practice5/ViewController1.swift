//
//  ViewController1.swift
//  practice5
//
//  Created by Training on 01/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController1: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var tblText: UITableView!
    
    
    let sectionsArr = ["colors","fruits"]
    let itemsArr = [
        ["Red","Blue"],
        ["Apple","Mango"]
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.sectionsArr.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemsArr[section].count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell1", for: indexPath) as! TableViewCell1
        cell.lblText!.text = itemsArr[indexPath.section][indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return self.sectionsArr[section]
    }
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        if section == 0 {
            return "Colors End"
        }else if section == 1 {
            return "Fruits End"
        }else{
            return "End"
        }
        
        ////
        //    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        ////        let Vw = UIView()
        //        Vw.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        //        return Vw
        //        let Vw = UIView(frame: CGRect (x: 0, y: 0, width: tableView.frame.size.width.height,: 20))
        
}




}




