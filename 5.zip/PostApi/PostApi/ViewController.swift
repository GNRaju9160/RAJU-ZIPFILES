

import UIKit
import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet weak var txtFldUser: UITextField!
    
    @IBOutlet weak var txtFldPassword: UITextField!
    let parameters = [
        "txtFldUser": "Kishore",
        "txtFldPassword": "123456"
    ]
    let url = "https://httpbin.org/post"
    
        override func viewDidLoad() {
        super.viewDidLoad()
        //      txtFldUser.text = "kishore"
        //     txtFldPassword.text = "123456"
    }
        @IBAction func actSave(_ sender: Any) {
        
        Alamofire.request(url, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: [:]).responseJSON {
            response in
            switch (response.result) {
            case .success:
                print(response)
                break
            case .failure:
                print(Error.self)
            }
        }
    }
}
//GlobalMethod.objGlobalMethod.ServiceMethod(url:urlPath, method:methodType, controller:self, parameters:params)
//{
//    response in
//
//    if response.result.value == nil {
//        print("No response")
//        return
//    }
//    else {
//        let responseData = response.result.value as! NSDictionary
//        print(responseData)
//    }
//}



