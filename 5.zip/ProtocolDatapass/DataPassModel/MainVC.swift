import UIKit
protocol UpdateData {
    func updateData(nameStr: String, mobStr: String )
}

var updateDataObj : UpdateData?


class MainVC: UIViewController {
    
    var nameStr = String()
    var mobStr = String()
    
    @IBOutlet weak var txtFldName2: UITextField!
    @IBOutlet weak var txtFldMob2: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtFldName2.text = nameStr
        txtFldMob2.text = mobStr
    }
    @IBAction func btnSave(_ sender: Any) {
        updateDataObj?.updateData(nameStr: txtFldName2.text!, mobStr: txtFldMob2.text!)
        self.dismiss(animated: true, completion: nil)
        
    }
}
