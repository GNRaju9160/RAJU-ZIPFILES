
import UIKit

class ViewController: UIViewController,UpdateData {

    
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldMobile: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        updateDataObj = self
    }
    @IBAction func btnNext1(_ sender: Any) {
    
        let nextVC = self.storyboard?.instantiateViewController(withIdentifier: "MainVC") as! MainVC
        
        nextVC.nameStr = txtFldName.text!
        nextVC.mobStr = txtFldMobile.text!
        
    
        self.present(nextVC, animated: true, completion: nil)
        
    }
    
    func updateData(nameStr: String,mobStr: String) {
        txtFldName.text = nameStr
        txtFldMobile.text = mobStr
    }
}
