//
//  File.swift
//  QuizeApp
//
//  Created by Training on 17/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import Foundation

var objLoginModel = LoginModel()

class LoginModel{
    
    var nameStr = String()
    var passwordStr = String()
    
    
}
