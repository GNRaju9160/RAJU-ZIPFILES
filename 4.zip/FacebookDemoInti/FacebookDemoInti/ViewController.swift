 

import UIKit
import FacebookCore
import FacebookLogin
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnFb(_ sender: Any) {
      let manager = LoginManager()
        manager.logIn(permissions: [.publicProfile, .email], viewController: self) { (result) in
            switch result {
            case .cancelled:
                print("User Cancelled Login Process")
                break
            case .failed(let error) :
                print("Process is not done")
                break
            case .success(let grantedPermissions, let declinePermission, let accessToken):
                print("accessToken == \(accessToken)")
                break
            }
        }
        
    }
    
}

