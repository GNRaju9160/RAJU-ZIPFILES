
import UIKit

class ViewController2: UIViewController {
      
    var nameStr = String()
    var mobStr = String()
    
    @IBOutlet weak var txtFldName2: UITextField!
    @IBOutlet weak var txtFldMobile2: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        txtFldName2.text = nameStr
        txtFldMobile2.text = mobStr
        
    }
    @IBAction func btnUpdate(_ sender: Any) {
 
        NotificationCenter.default.post(name: Notification.Name("logIn"), object: nil, userInfo: [nameStr: txtFldName2.text!, mobStr: txtFldName2.text! ])
        self.dismiss(animated: true, completion: nil)
      
    }

}
