
import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldMobile: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       NotificationCenter.default.addObserver(self, selector: #selector(controlNotification), name: Notification.Name("logIn"), object: nil)
        
    }
    @objc func controlNotification(_ notificationObj: Notification){
        
      //  let obj = notificationObj.userInfo
    }
    @IBAction func btnSave(_ sender: Any) {
        
        let secondVC = storyboard?.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
        secondVC.nameStr = txtFldName.text!
        secondVC.mobStr = txtFldMobile.text!
        self.present(secondVC, animated: true, completion: nil)
    }
    
    func updateData(nameStr: String,mobStr: String) {
        txtFldName.text = nameStr
        txtFldMobile.text = mobStr
    }
        
    }


