//
//  ViewController.swift
//  FaveButton@
//
//  Created by Training on 27/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var vwButtons: UIView!
    @IBOutlet weak var btnShows: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       vwButtons.isHidden = true
    }
    @IBAction func btnShow(_ sender: Any) {
       
        if btnShows.isSelected == true {
        vwButtons.isHidden = false
        } else {
            vwButtons.isHidden = true
        }
      
    }

}

