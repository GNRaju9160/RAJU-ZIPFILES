//
//  ViewController.swift
//  GoogleMap
//
//  Created by Training on 13/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit
import MapKit
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func btnDirection(_ sender: Any) {
        let latitude:
        
        
    }
    

}

