
import UIKit

class ViewController2: UIViewController {
    @IBOutlet weak var txtFldTrans: UITextField!
      var selectedData = ""
   
    override func viewDidLoad() {
        super.viewDidLoad()

        txtFldTrans.text = selectedData
    
        // Do any additional setup after loading the view.
    }
    @IBAction func btnBackAction(_ sender: Any) {
        
       NotificationCenter.default.post(name: NSNotification.Name("UpdateValue"), object: txtFldTrans.text!)
       self.navigationController?.popViewController(animated: true)
    }


    }
    
    
    
    
    
    

    
    
    
    
  //  func tableView(_ tableView: UITableView,didSelectRowAt indexPath: IndexPath) {
        
    //    self.txtFldName.text = arrName[indexPath.row] as? String



