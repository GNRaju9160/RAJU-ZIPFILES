//
//  ViewController3.swift
//  GallaryApp
//
//  Created by Training on 22/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController3: UIViewController {
    @IBOutlet weak var imgVw: UIImageView!
    var selectedImage : UIImage!
    override func viewDidLoad() {
        super.viewDidLoad()
        imgVw.image = selectedImage

        // Do any additional setup after loading the view.
    }
    

   

}
