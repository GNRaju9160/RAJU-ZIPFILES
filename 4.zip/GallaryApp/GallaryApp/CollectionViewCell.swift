//
//  CollectionViewCell.swift
//  GallaryApp
//
//  Created by Training on 22/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgCell: UIImageView!
}
