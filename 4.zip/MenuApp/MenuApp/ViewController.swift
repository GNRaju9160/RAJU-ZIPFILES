//
//  ViewController.swift
//  MenuApp
//
//  Created by Training on 29/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit
import SideMenu

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    
    @IBOutlet weak var tblVw: UITableView!
    var arrNames = ["Home","Profile","Settings","Password"]
    var arrImg = [(#imageLiteral(resourceName: "Home")),(#imageLiteral(resourceName: "Profile")),(#imageLiteral(resourceName: "Settings")),(#imageLiteral(resourceName: "Password"))]
    var segueIdentifier = ["Home","Profile","Settings","Password"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrNames.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as! TableViewCell
        cell.imgVw.image = arrImg[indexPath.row]
        cell.lblName.text = arrNames[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

     let vc = segueIdentifier[indexPath.row]
        let homeVc = storyboard?.instantiateViewController(withIdentifier: vc)
        self.navigationController?.pushViewController(homeVc!, animated: true)
        

        }
    
    }
   
    
//}

