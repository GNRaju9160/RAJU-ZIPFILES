//
//  SideMenuViewController.swift
//  MenuApp
//
//  Created by Training on 29/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class SideMenuViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    @IBAction func btnAction(_ sender: Any) {
    }
    
}
