//
//  ViewController3.swift
//  ModelVCPract
//
//  Created by Training on 18/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController3: UIViewController {
    @IBOutlet weak var imgVw3: UIImageView!
    @IBOutlet weak var txtFldName3: UITextField!
    
    @IBOutlet weak var txtFldClass3: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imgVw3.image = objLoginModel.imageUser
        txtFldName3.text = objLoginModel.NameStr
        txtFldClass3.text = objLoginModel.ClassStr
        
    }
    
    
    
}
