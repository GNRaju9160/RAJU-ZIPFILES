//
//  LoginModel.swift
//  ModelVCPract
//
//  Created by Training on 18/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import Foundation
import UIKit
var objLoginModel = LoginModel()

class LoginModel {
var imageUser = UIImage()
var NameStr = String()
var ClassStr = String()
var MobStr = String()
var EmailStr = String()
var CountryStr = String()
var StateStr = String()
var CityStr = String()
var AgeStr = String()
}
