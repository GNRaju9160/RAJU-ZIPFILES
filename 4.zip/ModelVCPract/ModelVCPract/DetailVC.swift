//
//  DetailVC.swift
//  ModelVCPract
//
//  Created by Training on 18/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class DetailVC: UIViewController {
    @IBOutlet weak var imgVw2: UIImageView!
    @IBOutlet weak var txtFldName2: UITextField!
    
    @IBOutlet weak var txtFldClass: UITextField!
    
    @IBOutlet weak var txtFldMob: UITextField!
    
    @IBOutlet weak var txtFldAge: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

     
    
    
    imgVw2.image = objLoginModel.imageUser
    txtFldName2.text = objLoginModel.NameStr
    txtFldClass.text = objLoginModel.ClassStr
    txtFldMob.text = objLoginModel.MobStr
    txtFldAge.text = objLoginModel.AgeStr
    
    }
    @IBAction func btnLogin(_ sender: Any) {
       
        
        objLoginModel.imageUser = imgVw2.image!
        objLoginModel.NameStr = txtFldName2.text!
        objLoginModel.ClassStr = txtFldClass.text!
        let nextVC = storyboard?.instantiateViewController(withIdentifier: "ViewController3") as! ViewController3
        self.navigationController?.pushViewController(nextVC, animated: true)
        
        
    }
   
    }
    

  

