
import UIKit
import MapKit

class ViewController: UIViewController {
    
    @IBOutlet weak var mkMapKit: MKMapView!
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createAnnotations(locations: locations)
    }
       let locations = [
            ["title": "Amritsar, AMR","latitude": 31.633641, "longitude": 74.874391],
            ["title": "Atmakur, ATR", "latitude": 15.875384, "longitude": 78.581210],
            ["title": "Kanya Kumari, KNK", "latitude": 8.335958, "longitude": 77.554936],
             ["title": "Hyderabad, HYD", "latitude": 17.373809, "longitude": 78.478300],
             ["title": "Gujarat, GJR", "latitude": 23.068637, "longitude": 71.335450],
              ["title": "New delhi, NDL", "latitude": 28.678143, "longitude": 77.190487],
              ["title": "Guwahati, GWT", "latitude": 26.147820,  "longitude": 91.726928],
                ["title": "Agartala, AGT", "latitude": 23.834995, "longitude": 91.595614]
    
    ]
    
    func createAnnotations(locations:[[String: Any]]){

        for location in locations {
            let annotation = MKPointAnnotation()
            annotation.title = location["title"] as? String
            annotation.coordinate = CLLocationCoordinate2D(latitude: location["latitude"] as! CLLocationDegrees, longitude: location["longitude"] as! CLLocationDegrees)
            mkMapKit.addAnnotation(annotation)

    }
        
    }

}


