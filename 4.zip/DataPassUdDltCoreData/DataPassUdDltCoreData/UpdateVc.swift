import UIKit
import CoreData

class UpdateVc: UIViewController {
    @IBOutlet weak var txtFldName2: UITextField!
    @IBOutlet weak var txtFldMobile2: UITextField!
    @IBOutlet weak var txtFldCity: UITextField!
    
    var userName : [NSManagedObject] = []
    var userMobile : [NSManagedObject] = []
    var userCity : [NSManagedObject] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let appD = UIApplication.shared.delegate as! AppDelegate
        
        let context = appD.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Users")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        
        let fetchRequest2 = NSFetchRequest<NSManagedObject>(entityName: "Users")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "mobile", ascending: true)]
        
        let fetchRequest3 = NSFetchRequest<NSManagedObject>(entityName: "Users")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "city", ascending: true)]
        do {
            userName = try context.fetch(fetchRequest)
            userMobile = try context.fetch(fetchRequest2)
            userCity = try context.fetch(fetchRequest3)
            if let name = userName[0].value(forKey: "name") {
                txtFldName2.text = (name as! String)
            }
            if let mobile = userMobile[0].value(forKey: "mobile") {
                txtFldMobile2.text = (mobile as? String)
            }
            if let mobile = userCity[0].value(forKey: "city") {
                txtFldCity.text = (mobile as? String)
            }

        }catch {
            print("")
        }
 }
    @IBAction func btnUpdate(_ sender: Any) {
        
        let appD = UIApplication.shared.delegate as! AppDelegate
        
        let managedObjectContext = appD.persistentContainer.viewContext
       let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Users")
        fetchRequest.predicate = NSPredicate (format: "name = %@ " , "Kishu")
        
        do{
       //     let test = try context.fetch(fetchRequest)
         //   let test = try context?.executeFetchRequest(fetchRequest)
            let test = try managedObjectContext.fetch(fetchRequest)
            let objectUpdate = test[0] as! NSManagedObject
            
        objectUpdate.setValue(txtFldName2.text, forKey: "name")
        objectUpdate.setValue(txtFldMobile2.text, forKey: "mobile")
        objectUpdate.setValue(txtFldCity.text, forKey: "city")
        
        
        do {
            try managedObjectContext.save()
            print("Data Update")
        }
        catch {
            print("Not update")
            
        }
    }
    
//    
//    func textField(textField: UITextField!, shouldChangeCharactersInRange range: NSRange, replacementString string: String!) -> Bool {
//}
       
//    @IBAction func btnDelete(_ sender: Any) {
//    }
//
//
//func textFieldShouldClear(_ textField: UITextField) -> Bool {
// 
//}

    }
    
}

