
import Foundation
import CoreData
import UIKit

class DataModel {
    static var sharInstance = DataModel()
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    func save(object:[String: String]){
        let user = NSEntityDescription.insertNewObject(forEntityName: "User", into: context!) as! User
        user.name = object["name"]
        user.mobile = object["mobile"]
        user.city = object["city"]
        
        do
        {
            try context?.save()
            
        }
        catch
        {
            print("data is saved")
        }
        print("inserted")
    }
    func getData() -> [User]{
        var user = [User] ()
        let fetchReqeust = NSFetchRequestResult(entityName: "User")

        do{
            user = try context?.fetch(fetchReqeust) as! [USER]
        }
        catch
        {
            print("can't get data")
        }
        return user
    }
//    func deleteData(index:Int) ->[User] {
//        var user = getData()
//        context?.delete(user[index])
//        user.remove(at: index)
//
//        do
//        {
//            try context?.save()
//        }
//        catch
//        {
//            print("connot delete data")
//        }
//        print("data is delete")
//        return user
//    }
//    func editData(object:[String:String], i:Int)
//    var user = getData()
//    user[i].name = object["name"]
//    user[i].mobile = object["mobile"]
//    user[i].city = object["city"]
//    do
//    {
//    try context?.save()
//    }
//    catch
//    {
//    print("data is not edit")
//
//    }
       }


