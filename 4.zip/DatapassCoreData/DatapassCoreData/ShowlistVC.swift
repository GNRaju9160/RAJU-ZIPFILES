

import UIKit
protocol DataPass {
    func data(object:[String:String], index:Int, isEdit: Bool)
}
class ShowlistVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
  
    
     @IBOutlet weak var tblVwUser: UITableView!
    
    var user = [User]()
    var delegate: DataPass!
    
    override func viewDidLoad() {
        super.viewDidLoad()
user = DataModel.sharInstance.getData()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return user.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     let cell = tableView.dequeueReusableCell(withIdentifier: "DetailTvc") as! DetailTvc
        cell.user = user[indexPath.row]
        return cell
    }
    
        
    }


