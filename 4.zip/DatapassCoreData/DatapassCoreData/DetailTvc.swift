
import UIKit

class DetailTvc: UITableViewCell {
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblMobile: UILabel!
    @IBOutlet weak var lblCity: UILabel!
    
    var user:User! {
        
        didSet {
            lblName.text = user.name
            lblMobile.text = user.mobile
            lblCity.text = user.city
            
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
