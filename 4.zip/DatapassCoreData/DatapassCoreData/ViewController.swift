
import UIKit
import CoreData

class ViewController: UIViewController,DataPass {
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldMobile: UITextField!
    @IBOutlet weak var txtFldCity: UITextField!
  
    var i = Int()
    var isUpdate = Bool()

    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    @IBAction func btnSave(_ sender: Any) {
        let dict = ["name":txtFldName.text,"mobile":txtFldMobile.text,"city":txtFldCity.text]
        if isUpdate{
            DataModel.sharInstance.editData(object: dict as! [String: String], i: i)
        }else{
            DataModel.sharInstance.save(object: dict as! [String : String])
        }
     }
    
    @IBAction func actShowList(_ sender: Any) {
      let nextVc = self.storyboard?.instantiateViewController(withIdentifier: "ShowlistVC") as! ShowlistVC
        nextVc.delegate = self
        self.navigationController?.pushViewController(nextVc, animated: true)
    }
    func data(object: [String : String], index: Int, isEdit: Bool){
        txtFldName.text = object["name"]
        txtFldMobile.text = object["mobile"]
        txtFldCity.text = object["city"]
        i = index
        isUpdate = isEdit
        
    
       
        
    }
    

}

