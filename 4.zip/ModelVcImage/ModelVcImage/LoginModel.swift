//
//  LoginModel.swift
//  ModelVcImage
//
//  Created by Training on 17/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import Foundation
import UIKit


var objLoginModel = LoginModel()
class LoginModel {
    
    var ImageUser = UIImage()
    var NameStr = String()
    var PassStr = String()
    var MobStr = String()
    var EmailStr = String()
    var ClassStr = String()
    var CityStr = String()
    var StateStr = String()
    
}
