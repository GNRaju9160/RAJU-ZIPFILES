//
//  Model.swift
//  DataPassTxtFld
//
//  Created by Training on 14/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import Foundation
//var objModel = LoginModel ()
//class LoginModel {
//var nameStr = String()
//    var cellStr = String()
//    
//}
