//
//  ViewController.swift

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldCell: UITextField!
    
      override func viewDidLoad() {
        super.viewDidLoad()
     
    }
    @IBAction func btnMove(_ sender: Any) {
        let nextVc = storyboard?.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
        
        nextVc.lblName?.text = txtFldName.text!
          nextVc.lblCell?.text = txtFldCell.text!
        
        
        self.navigationController?.pushViewController(nextVc, animated: true)
        
//        objModel.nameStr = txtFldName.text!
//        objModel.cellStr = txtFldCell.text!
        
        
    }
    

}

