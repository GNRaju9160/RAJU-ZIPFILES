
import UIKit

class VwController: UIViewController {
    
    @IBOutlet weak var proView: UIProgressView!
    @IBOutlet weak var lblNumber: UILabel!
    @IBOutlet weak var btnPlay: UIButton!
    @IBOutlet weak var btnReset: UIButton!
    @IBOutlet weak var btnPause: UIButton!
    var myTimer: Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.myTimer = Timer()
        self.proView.progress = 0.0
        let progressValue = Int(self.proView.progress * 100)
        self.lblNumber.text = "\(progressValue)"
        
        self.btnPlay.isEnabled = true
        self.btnReset.isEnabled = false
        self.btnPause.isEnabled = false
        
        self.myTimer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(VwController.updateProgress), userInfo: nil, repeats: true)
        self.btnPlay.isEnabled = false
        self.btnReset.isEnabled = false
        self.btnPause.isEnabled = true
        
    }
    @objc func updateProgress() {
        self.proView.progress += 0.01
        self.lblNumber.text = "\(Int(self.proView.progress * 100))"
        if self.proView.progress >= 1 {
            self.myTimer?.invalidate()
            self.btnPlay.isEnabled = true
            self.btnReset.isEnabled = true
            self.btnPause.isEnabled = false
    
        }
    }
    @IBAction func actionPlay(_ sender: Any) {
        if self.proView.progress < 1 {
//         self.proView.progress = 0.0
            self.myTimer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(VwController.updateProgress), userInfo: nil, repeats: true)
            self.btnPlay.isEnabled = false
            self.btnReset.isEnabled = false
            self.btnPause.isEnabled = true
            
        }
    }
    @IBAction func actionReset(_ sender: Any) {
      
        self.proView.progress = 0.0
        self.lblNumber.text = "0"
        self.btnPlay.isEnabled = true
        self.btnReset.isEnabled = true
        self.btnPause.isEnabled = false
      
    }
    @IBAction func actionPause(_ sender: Any) {
        self.myTimer?.invalidate()
        self.btnPlay.isEnabled = true
        self.btnReset.isEnabled = true
        self.btnPause.isEnabled = false
   
    }
    
}





