//
//  ViewController3.swift
//  Indicator
//
//  Created by Training on 16/10/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class ViewController3: UIViewController {
    @IBOutlet weak var proView: UIProgressView!
    @IBOutlet weak var lblValue: UILabel!
    
    let progress = Progress(totalUnitCount: 10)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    @IBAction func btnDownload(_ sender: Any) {
        
        if self.proView.progress >= 1 {
            self.proView.progress = 0.0
        }
        // 1
        proView.progress = 0.0
        progress.completedUnitCount = 0
        
        // 2
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (timer) in
            guard self.progress.isFinished == false else {
                timer.invalidate()
                
                return
            }
            
            // 3
            self.progress.completedUnitCount += 1
            self.proView.setProgress(Float(self.progress.fractionCompleted), animated: true)
            
            self.lblValue.text = "\(Int(self.progress.fractionCompleted * 100)) %"
        }
        
    }
}

