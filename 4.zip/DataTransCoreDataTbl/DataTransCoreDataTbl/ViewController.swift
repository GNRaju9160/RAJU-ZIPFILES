
import UIKit
import CoreData

class ViewController: UIViewController {
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldMobile: UITextField!
    @IBOutlet weak var txtFldCity: UITextField!

 
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }

    @IBAction func actSave(_ sender: Any) {
        let appD = UIApplication.shared.delegate as! AppDelegate
        
        let context = appD.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Users", in : context)!
        
        let theTitle = NSManagedObject(entity: entity, insertInto: context)
        theTitle.setValue(txtFldName.text, forKey: "name")
        theTitle.setValue(txtFldMobile.text, forKey: "mobile")
        theTitle.setValue(txtFldCity.text, forKey: "city")
          do {
            try context.save()
            print("Data Saved")
        }
        catch {
            print("Not save")
        }
    }
     @IBAction func actShowlist(_ sender: Any) {
        let nextVC = self.storyboard?.instantiateViewController(withIdentifier: "TblListVc") as! TblListVc
      
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
}

