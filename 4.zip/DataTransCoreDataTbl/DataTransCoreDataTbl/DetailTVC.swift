//
//  DetailTVC.swift
//  DataTransCoreDataTbl
//
//  Created by Training on 12/11/19.
//  Copyright © 2019 Training. All rights reserved.
//

import UIKit

class DetailTVC: UITableViewCell {
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblMobile: UILabel!
    @IBOutlet weak var lblCity: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
