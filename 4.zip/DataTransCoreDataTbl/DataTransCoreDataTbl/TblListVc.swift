
import UIKit
import CoreData

class TblListVc: UIViewController,UITableViewDataSource,UITableViewDelegate {
   
   
    
    @IBOutlet weak var tblVwList: UITableView!

    var details = [Users]()
    
    var userName : [NSManagedObject] = []
    var userMobile : [NSManagedObject] = []
    var userCity : [NSManagedObject] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//
//     tblVwList.delegate  = self
//    tblVwList.dataSource = self
        let appD = UIApplication.shared.delegate as! AppDelegate
        
        let context = appD.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Users")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        
        let fetchRequest2 = NSFetchRequest<NSManagedObject>(entityName: "Users")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "mobile", ascending: true)]
        
        let fetchRequest3 = NSFetchRequest<NSManagedObject>(entityName: "Users")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "city", ascending: true)]
        do {
            

    
//  self.tblVwList.reloadData()
        }
       
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
             return details.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "DetailTVC") as! DetailTVC
            cell.lblName.text = details[indexPath.row].name
            cell.lblMobile.text = details[indexPath.row].mobile
            cell.lblCity.text = details[indexPath.row].city
            
            return cell
        }
        
    
    
}


}
