
import UIKit
import MapKit

class ViewController: UIViewController,MKMapViewDelegate {
    
    @IBOutlet weak var mapKitView: MKMapView!
    
    let initialLocation = CLLocation(latitude: 15.875385, longitude: 78.581212)
  //  let initialLocation2 = CLLocation(latitude: 31.633641,  longitude: 74.874391)
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        let artwork = Artwork(title: "Gunja Nageswara Rao",
                              locationName: "Saibaba nagar",
                              discipline: "Atmakur",
                              coordinate: CLLocationCoordinate2D(latitude: 15.875385, longitude: 78.581212))
        mapKitView.addAnnotation(artwork)
    }
    let regionRadius: CLLocationDistance = 1000
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegion(center: location.coordinate,
                                                  latitudinalMeters: regionRadius, longitudinalMeters: regionRadius)
        mapKitView.setRegion(coordinateRegion, animated: true)
        centerMapOnLocation(location: initialLocation)
        

//
//        let artwork = Artwork(title: "Sukpreetmam",
//                              locationName: "Amritsar",
//                              discipline: "Punjab",
//                              coordinate: CLLocationCoordinate2D(latitude: 31.633641,  longitude: 74.874391))
//        mapKitView.addAnnotation(artwork)
//    }
//    let regionRadius2 : CLLocationDistance = 1000
//    func centerMapOnLocation2(location: CLLocation) {
//        let coordinateRegion = MKCoordinateRegion(center: location.coordinate,
//                                                  latitudinalMeters: regionRadius2, longitudinalMeters: regionRadius2)
//        mapKitView.setRegion(coordinateRegion, animated: true)
//        centerMapOnLocation2(location: initialLocation2)
    }
 
        // 1
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            // 2
            guard let annotation = annotation as? Artwork else { return nil }
            // 3
            let identifier = "marker"
            var view: MKMarkerAnnotationView
            // 4
            if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
                as? MKMarkerAnnotationView {
                dequeuedView.annotation = annotation
                view = dequeuedView
            } else {
                // 5
                view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                view.canShowCallout = true
                view.calloutOffset = CGPoint(x: -5, y: 5)
                view.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
            }
            return view
        }

}

